matrixRain({
  canvas: '#my-canvas',
}).run();